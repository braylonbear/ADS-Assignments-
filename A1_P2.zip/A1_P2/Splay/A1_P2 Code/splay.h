// splay.h
#ifndef SPLAY_H
#define SPLAY_H

#include <iostream>
using namespace std;

class SplayTree
{
private:
    int rotationCount;
    int totalDepth;
    int searchCount;

    struct Node
    {
        int key;
        int weight;
        Node* left;
        Node* right;

        Node(int k)
        {
            key = k;
            weight = 1;
            left = nullptr;
            right = nullptr;
        }
    };

    Node* root;

    Node* rotateRight(Node* x);
    Node* rotateLeft(Node* x);

    Node* splayBU(Node* root, int key);
    Node* splayTD(Node* root, int key);

    Node* insertNode(Node* root, int key);
    Node* deleteNodeBU(Node* root, int key);

    Node* semiSplayTD(Node* root, int key, int& rotations, int maxRotations);

    Node* weightedSplayTD(Node* root, int key);
    Node* findNode(Node* root, int key);

    int findDepth(Node* root, int key);

    void printTree(Node* root, int space);

public:
    SplayTree();

    void insert(int key);

    void removeBU(int key);
    void removeTD(int key);

    bool searchBU(int key);
    bool searchTD(int key);

    void semiSplay(int key);
    bool semiSearch(int key);

    bool weightedSearch(int key);

    void resetMetrics();
    int getRotationCount();
    double getAverageDepth();

    void display();
};

#endif
