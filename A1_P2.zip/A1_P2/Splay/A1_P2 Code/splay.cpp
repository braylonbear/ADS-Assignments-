#include "splay.h"
#include <iostream>
#include <vector>
#include <chrono>
using namespace std;

SplayTree::SplayTree() 
{
    root = nullptr; 
    rotationCount = 0;
    totalDepth = 0;
    searchCount = 0;
}

// aka Zig
SplayTree::Node* SplayTree::rotateRight(Node* x) 
{
    Node* y = x->left;
    x->left = y->right; 
    y->right = x;

    rotationCount++;

    return y;
}

// aka Zag
SplayTree::Node* SplayTree::rotateLeft(Node* x) 
{
    Node* y = x->right;
    x->right = y->left;
    y->left = x;

    rotationCount++;

    return y;
}

SplayTree::Node* SplayTree::splayBU(Node* root, int key)
{
    if (root == nullptr || root->key == key)
        return root;

    if (key < root->key)
    {
        if (root->left == nullptr)
            return root;

        if (key < root->left->key)
        {
            root->left->left = splayBU(root->left->left, key);
            root = rotateRight(root);
        }
        else if (key > root->left->key)
        {
            root->left->right = splayBU(root->left->right, key);
            if (root->left->right != nullptr)
                root->left = rotateLeft(root->left);
        }

        if (root->left != nullptr)
            root = rotateRight(root);
    }
    else
    {
        if (root->right == nullptr)
            return root;

        if (key > root->right->key)
        {
            root->right->right = splayBU(root->right->right, key);
            root = rotateLeft(root);
        }
        else if (key < root->right->key)
        {
            root->right->left = splayBU(root->right->left, key);
            if (root->right->left != nullptr)
                root->right = rotateRight(root->right);
        }

        if (root->right != nullptr)
            root = rotateLeft(root);
    }

    return root;
}

SplayTree::Node* SplayTree::splayTD(Node* root, int key)
{
    if (root == nullptr)
        return nullptr;

    Node N(0);
    Node* leftTreeMax = &N;
    Node* rightTreeMin = &N;

    while (true)
    {
        if (key < root->key)
        {
            if (root->left == nullptr)
                break;

            if (key < root->left->key)
                root = rotateRight(root);

            if (root->left == nullptr)
                break;

            rightTreeMin->left = root;
            rightTreeMin = root;
            root = root->left;
        }
        else if (key > root->key)
        {
            if (root->right == nullptr)
                break;

            if (key > root->right->key)
                root = rotateLeft(root);

            if (root->right == nullptr)
                break;

            leftTreeMax->right = root;
            leftTreeMax = root;
            root = root->right;
        }
        else
            break;
    }

    leftTreeMax->right = root->left;
    rightTreeMin->left = root->right;

    root->left = N.right;
    root->right = N.left;

    return root;
}

SplayTree::Node* SplayTree::insertNode(Node* root, int key) 
{
    if (root == nullptr)
        return new Node(key);

    root = splayBU(root, key);

    if(root->key == key)
        return root;

    Node* newNode = new Node(key);
    if (key < root->key)
    {
        newNode->right = root;
        newNode->left = root->left;
        root->left = nullptr;
    }
    else
    {
        newNode->left = root;
        newNode->right = root->right;
        root->right = nullptr;
    }

    return newNode;
}

void SplayTree::insert(int key) 
{
    root = insertNode(root, key);
}

SplayTree::Node* SplayTree::deleteNodeBU(Node* root, int key)
{
    if (root == nullptr)
        return nullptr;

    root = splayBU(root, key);

    if (root->key != key)
        return root;

    Node* temp;

    if (root->left == nullptr)
    {
        temp = root;
        root = root->right;
    }
    else
    {
        temp = root;
        Node* rightSub = root->right;
        root = root->left;
        root = splayBU(root, key);
        root->right = rightSub;
    }

    delete temp;
    return root;
}

void SplayTree::removeBU(int key) 
{
    root = deleteNodeBU(root, key);
}

void SplayTree::removeTD(int key) 
{
    root = deleteNodeBU(root, key);
}

bool SplayTree::searchBU(int key)
{
    int d = findDepth(root, key); 
    root = splayBU(root, key);

    searchCount++;
    totalDepth += d;

    return (root != nullptr && root->key == key);
}

bool SplayTree::searchTD(int key)
{
    int d = findDepth(root, key);
    root = splayTD(root, key);

    searchCount++;
    totalDepth += d;

    return (root != nullptr && root->key == key);
}

SplayTree::Node* SplayTree::semiSplayTD(Node* root, int key, int& rotations, int maxRotations)
{
    if (!root || rotations >= maxRotations)
        return root;
    if (key < root->key)
    {
        if (!root->left)
            return root;

        if (key < root->left->key)
        {
            root->left->left = semiSplayTD(root->left->left, key, rotations, maxRotations);

            if (rotations < maxRotations)
            {
                root = rotateRight(root);
                rotations++;
            }
        }
        else if (key > root->left->key)
        {
            root->left->right = semiSplayTD(root->left->right, key, rotations, maxRotations);

            if (root->left && rotations < maxRotations)
            {
                root->left = rotateLeft(root->left);
                rotations++;
            }
        }

        if (rotations < maxRotations)
        {
            root = rotateRight(root);
            rotations++;
        }
    }
    else if (key > root->key)
    {
        if (!root->right)
            return root;

        if (key > root->right->key)
        {
            root->right->right = semiSplayTD(root->right->right, key, rotations, maxRotations);

            if (rotations < maxRotations)
            {
                root = rotateLeft(root);
                rotations++;
            }
        }
        else if (key < root->right->key)
        {
            root->right->left = semiSplayTD(root->right->left, key, rotations, maxRotations);

            if (root->right && rotations < maxRotations)
            {
                root->right = rotateRight(root->right);
                rotations++;
            }
        }

        if (rotations < maxRotations)
        {
            root = rotateLeft(root);
            rotations++;
        }
    }

    return root;
}

void SplayTree::semiSplay(int key)
{
    int depth = findDepth(root, key);
    if (depth == -1)
        return;

    int maxRotations = depth / 2;
    int rotations = 0;
    root = semiSplayTD(root, key, rotations, maxRotations);
}

bool SplayTree::semiSearch(int key)
{
    int d = findDepth(root, key); 

    semiSplay(key);             

    searchCount++;
    totalDepth += d;

    Node* curr = root;
    while (curr != nullptr)
    {
        if (key == curr->key) return true;
        else if (key < curr->key) curr = curr->left;
        else curr = curr->right;
    }
    return false;
}


SplayTree::Node* SplayTree::weightedSplayTD(Node* root, int key)
{
    if (root == nullptr)
        return nullptr;

    Node N(0);
    Node* leftTreeMax = &N;
    Node* rightTreeMin = &N;

    while (true)
    {
        if (key < root->key)
        {
            if (root->left == nullptr)
                break;

            if (key < root->left->key &&
                root->left->left != nullptr &&
                root->left->weight >= root->weight)
            {
                root = rotateRight(root);
            }

            if (root->left == nullptr)
                break;

            rightTreeMin->left = root;
            rightTreeMin = root;
            root = root->left;
        }
        else if (key > root->key)
        {
            if (root->right == nullptr)
                break;

            if (key > root->right->key &&
                root->right->right != nullptr &&
                root->right->weight >= root->weight)
            {
                root = rotateLeft(root);
            }

            if (root->right == nullptr)
                break;

            leftTreeMax->right = root;
            leftTreeMax = root;
            root = root->right;
        }
        else
        {
            break;
        }
    }

    leftTreeMax->right = root->left;
    rightTreeMin->left = root->right;

    root->left = N.right;
    root->right = N.left;

    return root;
}

SplayTree::Node* SplayTree::findNode(Node* root, int key)
{
    while (root != nullptr)
    {
        if (key == root->key) return root;
        else if (key < root->key) root = root->left;
        else root = root->right;
    }
    return nullptr;
}

bool SplayTree::weightedSearch(int key)
{
    int d = findDepth(root, key); 

    Node* target = findNode(root, key);
    if (target == nullptr)
    {
        searchCount++;
        totalDepth += d;
        return false;
    }   
    target->weight++;

    root = weightedSplayTD(root, key);

    searchCount++;
    totalDepth += d;
    return true;
}

int SplayTree::findDepth(Node* root, int key)
{
    int depth = 0;

    while (root != nullptr)
    {
        if (key == root->key)
        {
            return depth;
        }
        else if (key < root->key)
        {
            root = root->left;
        }
        else
        {
            root = root->right;
        }

        depth++;
    }

    return depth; 
}

void SplayTree::resetMetrics()
{
    rotationCount = 0;
    totalDepth = 0;
    searchCount = 0;
}

int SplayTree::getRotationCount()
{
    return rotationCount;
}

double SplayTree::getAverageDepth()
{
    if (searchCount == 0)
        return 0;

    return (double)totalDepth / searchCount;
}

void SplayTree::printTree(Node* root, int space)
{
    const int COUNT = 10; 
    if (root == nullptr)
        return;

    space += COUNT;
    printTree(root->right, space);

    for (int i = COUNT; i < space; i++)
        cout << " ";
    cout << root->key << endl;

    printTree(root->left, space);
}

void SplayTree::display()
{
    printTree(root, 0);
    cout << endl;
}



