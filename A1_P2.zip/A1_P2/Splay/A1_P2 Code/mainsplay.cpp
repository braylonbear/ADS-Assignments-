#include "splay.h"
#include <vector>
#include <iostream>
#include <fstream>
#include <chrono>
using namespace std;

int main()
{
    SplayTree tree;
    ifstream infile("working_set.txt");
    int value;

    if (!infile) {
        cerr << "Error: Could not open file." << endl;
        return 1;
    }

    while (infile >> value) {
        tree.insert(value);
    }
    infile.close();

    vector<int> accesses = {20, 30, 40, 60, 70, 80};

    tree.resetMetrics();

    auto start = chrono::high_resolution_clock::now();

    for (int key : accesses)
        tree.weightedSearch(key);  

    auto end = chrono::high_resolution_clock::now();
    chrono::duration<double> totalTime = end - start;

    cout << "Total rotations: " << tree.getRotationCount() << "\n";
    cout << "Average Search Depth: " << tree.getAverageDepth() << "\n";
    cout << "Total time: " << totalTime.count() << " seconds\n";

    return 0;
}
