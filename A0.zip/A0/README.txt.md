BST Project - A0



Description: 



In this BST, I implemented all of the required operations for each task and have a example input that it needs to run that shows each function working.



Files: 

bst.h

bst.cpp

mainbst.cpp

bst\_test



How it works:



In the input file, it associates numbers with a certain function. Each number means:



-1 = remove

1  = insert
2  = search

3  = pre order

4  = in order

5  = post order

6  = printBST

7  = Number of nodes

8  = Height

9  = Which side is taller

10 = balanced or not

11 = height of a node





