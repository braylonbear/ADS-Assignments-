#include <iostream>
using namespace std;

// tree node for linked BST
struct treenode
{
    int dat;
    treenode *lchild;
    treenode *rchild;
};

class bstree
{
public:
    bstree();
    void in();
    void pre();
    void post();
    int insert(int x);
    int remove(int x);
    int search(int x);
    int numnodes();
    int height();
    bool balance();
    int side();
    int heightOfNode(int val);
    bool isWorstCase();
    void printBST();
private:
    int searchR(treenode *t, int x);
    int insertR(treenode *&t, int x);
    void in(treenode *t);
    void pre(treenode *t);
    void post(treenode *t);
    int remove(treenode *&t, int x);
    int numnodes(treenode *t);
    int height(treenode *t);
    bool balance(treenode *t);
    int getMin(treenode *t);
    int side(treenode *t);
    treenode *root;
    treenode* findNode(treenode*, int val);
    void printBST(treenode* t, int depth);
};

treenode *makeatreenode(int x);
