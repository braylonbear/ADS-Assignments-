#include "bst.h"
// allocate a new node
//   not part of the class
treenode *makeatreenode( int x )
{
        treenode *node;
        node = new treenode;
        node->dat = x;
        node->lchild = NULL;
        node->rchild = NULL;

        return node;
}



bstree::bstree()
{
        root = NULL;
}

void bstree::in( treenode *t )
{
        if (t == NULL)
                return;
        in(t->lchild);
                cout << t->dat << " ";
        in(t->rchild);
}

void bstree::in()
{
        cout << "In: ";
        in(root);
        cout << endl;
}

void bstree::pre( treenode *t )
{
        if (t == NULL)
                return;
        cout << t->dat << " ";
        pre(t->lchild);
        pre(t->rchild);
}
void bstree::pre()
{
        cout << "Pre: ";
        pre(root);
        cout << endl;
}

void bstree::post( treenode *t)
{
        if (t == NULL)
                return;
        post(t->lchild);
        post(t->rchild);
        cout << t->dat << " ";
}

void bstree::post()
{
        cout << "Post: ";
        post(root);
        cout << endl;
}

int bstree::insert( int val )
{
        int result = insertR(root, val);

        if (result == 1 && isWorstCase())
                cout << "Warning: tree has reached worst-case configuration" << endl;

        return result;

}

int bstree::insertR( treenode*& t, int val )
{
        if (t == NULL)
        {
                t = makeatreenode(val);
                return 1;
        }

        if (t->dat == val)
                return 2;
        if (val < t->dat)
                return insertR(t->lchild, val);
        else
                return insertR(t->rchild, val);
}


int bstree::search( int val )
{
        return searchR(root, val);
}

int bstree::searchR(treenode *t, int val)
{
        if (t == NULL)
                return 0;

        if (t->dat == val)
                return 1;

        if (val < t->dat)
                return searchR(t->lchild, val);
        else
                return searchR(t->rchild, val);
}

int bstree::height()
{
        return height(root);
}

int bstree::height( treenode *t )
{
    if (t == NULL)
        return -1;

    int hl = height(t->lchild);
    int hr = height(t->rchild);

    return 1 + max(hl, hr);
}

bool bstree::balance()
{
    return balance(root);
}

bool bstree::balance( treenode *t )
{
        if (t == NULL)
                return true;
        int hl, hr;
        hl = height(t->lchild);
        hr = height(t->rchild);

        if (abs(hl - hr) > 1)
                return false;
        
        return balance(t->lchild) && balance(t->rchild);
}

int bstree::numnodes()
{
        return numnodes( root );
}

int bstree::numnodes( treenode *t)
{
        if ( t == NULL )
                return 0;
        if (t->lchild == NULL && t->rchild == NULL)
                return 1;

        int count;
        count = 1 + numnodes( t->lchild ) + numnodes( t->rchild );

        return count;
}

int bstree::getMin( treenode *t )
{
        if ( t == NULL )
                return 0;
        if (t->lchild == NULL && t->rchild == NULL)
                return t->dat;
        else
                while (t->lchild != NULL)
                {
                        t = t->lchild;
                }
        return t->dat;
}

int bstree::remove( int val )
{
        return remove( root, val );
}

int bstree::remove( treenode*& t, int val)
{
     if (t == NULL)
        return 0;

    if (val < t->dat)
        return remove(t->lchild, val);

    if (val > t->dat)
        return remove(t->rchild, val);
        
    if (t->lchild == NULL && t->rchild == NULL)
    {
        delete t;
        t = NULL;
        return 1;
    }

    if (t->lchild == NULL)
    {
        treenode* temp = t;
        t = t->rchild;
        delete temp;
        return 1;
    }

    if (t->rchild == NULL)
    {
        treenode* temp = t;
        t = t->lchild;
        delete temp;
        return 1;
    }

    int successor = getMin(t->rchild);
    t->dat = successor;
    return remove(t->rchild, successor);
}

int bstree::side()
{
        return side( root );
}

int bstree::side( treenode *t )
{
        int left = height(t->lchild);
        int right = height(t->rchild);

        if (left > right)
                return 0;
        if (left < right)
                return 1;
        else
                return 3;
}

treenode* bstree::findNode(treenode* t, int val)
{
        if (t == NULL)
                return NULL;

        if (t->dat == val)
                return t;

        if (val < t->dat)
                return findNode(t->lchild, val);
        else
                return findNode(t->rchild, val);
}

int bstree::heightOfNode(int val)
{
        treenode* node = findNode(root, val);

        if (node == NULL)
                return -1;

        return height(node); 
}

bool bstree::isWorstCase()
{
        if (root == NULL)
            return false;

        return height() == numnodes() - 1;
}

void bstree::printBST()
{
    printBST(root, 0);
}

void bstree::printBST(treenode* t, int depth)
{
    if (t == NULL)
        return;

    printBST(t->rchild, depth + 1);

    for (int i = 0; i < depth; i++)
        cout << "   ";

    cout << t->dat << endl;

    printBST(t->lchild, depth + 1);
}
