#include "bst.h"

#include <fstream>
#include <iostream>
using namespace std;

int main(int argc, char* argv[])
{
    if (argc < 2)
    {
        cout << "Usage: mainbst <input_file>\n";
        return 1;
    }

    bstree tree;
    FILE *fp = fopen(argv[1], "r");
    if (!fp)
    {
        cout << "Error: Could not open file\n";
        return 1;
    }

    int num1, num2;
    fscanf(fp, "%d", &num1);
    while (num1 != 0)
    {
        if (num1 == 1)
        {
            fscanf(fp, "%d", &num2);
            int result = tree.insert(num2);
            if (result == 1)
                cout << "Inserted " << num2 << endl;
            else
                cout << num2 << " is already in the tree" << endl;
        }
        else if (num1 == 2)
        {
            fscanf(fp, "%d", &num2);
            int result = tree.search(num2);
            if (result)
                cout << num2 << " was found" << endl;
            else if (tree.numnodes() == 0)
                cout << "The tree is empty" << endl;
            else
                cout << num2 << " was not found" << endl;
        }
        else if (num1 == 3) 
            tree.pre();
        else if (num1 == 4) 
            tree.in();
        else if (num1 == 5) 
            tree.post();
        else if (num1 == -1)
        {
            fscanf(fp, "%d", &num2);
            int result = tree.remove(num2);
            if (result == 1)
                cout << num2 << " was successfully removed" << endl;
            else
                cout << num2 << " is not in the tree" << endl;
        }
        else if (num1 == 6)
            tree.printBST();
        else if (num1 == 7) 
            cout << tree.numnodes() << " nodes in tree" << endl;
        else if (num1 == 8) 
            cout << "Height of tree is " << tree.height() << endl;
        else if (num1 == 9)
        {
            int result = tree.side();
            if (result == 0) cout << "The left side is taller" << endl;
            else if (result == 1) cout << "The right side is taller" << endl;
            else cout << "Equal height" << endl;
        }
        else if (num1 == 10)
        {
            if (!tree.balance()) cout << "The tree is not balanced" << endl;
            else cout << "The tree is balanced" << endl;
        }
        else if (num1 == 11)
        {
            fscanf(fp, "%d", &num2);
            int result = tree.heightOfNode(num2);
            if (result == -1)
                cout << num2 << " is not in the tree" << endl;
            else
                cout << "Height of node " << num2 << " is " << result << endl;
        }

        fscanf(fp, "%d", &num1);
    }

    fclose(fp);
}
